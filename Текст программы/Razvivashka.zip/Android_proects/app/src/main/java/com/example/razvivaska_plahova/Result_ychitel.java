package com.example.razvivaska_plahova;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
public class Result_ychitel extends AppCompatActivity {

    private EditText emailInput;
    private EditText idInput;
    private RecyclerView recyclerView;
    private ResultsAdapter adapter;
    private List<Result> results = new ArrayList<>();
    private Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_ychitel);
        emailInput = findViewById(R.id.emailInput); // ID вашего EditText для email

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ResultsAdapter(this, results);
        recyclerView.setAdapter(adapter);
        save = findViewById(R.id.save);
        findViewById(R.id.searchButton).setOnClickListener(view -> {
            String email = emailInput.getText().toString().trim();

            loadResultsFromFirestore(email);
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, "results.txt"); // имя файла
                values.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain"); // тип содержимого
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + File.separator + "Razvivashka"); // путь

                Uri uri = getContentResolver().insert(MediaStore.Files.getContentUri("external"), values); // создание URI для файла

                try {
                    if (uri != null) {
                        OutputStream outputStream = getContentResolver().openOutputStream(uri);
                        for (Result result : results) {
                            if (outputStream != null) {
                                outputStream.write((result.getEmail() + ", Оценка:" +
                                        result.getGrade() + ", Результат в %:" +
                                        String.valueOf(result.getResult()) + ", Предмет:" +
                                        result.getSubject() + ", Название теста:" +
                                        result.getTestName() + ", Тема:" +
                                        result.getTheme() + "\n").getBytes());
                            }
                        }
                        if (outputStream != null) {
                            outputStream.close();
                        }
                        Toast.makeText(Result_ychitel.this, "Результаты сохранены в папке 'Загрузки'", Toast.LENGTH_SHORT).show();
                    }
                } catch (IOException e) {
                    Log.w("File writing error", "Ошибка при записи файла: " + e.getMessage());
                    Toast.makeText(Result_ychitel.this, "Ошибка при сохранении файлов: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    private void loadResultsFromFirestore(String email) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("results")
                .whereEqualTo("email", email)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    results.clear();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        String grade = document.getString("grade");
                        int result = document.getLong("result").intValue();
                        String subject = document.getString("subject");
                        String testName = document.getString("testName");
                        String theme = document.getString("theme");

                        Result resultItem = new Result(email, grade, result, subject, testName, theme);
                        results.add(resultItem);
                    }
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
                    // Обработка ошибки загрузки данных
                    Toast.makeText(this, "Ошибка загрузки данных", Toast.LENGTH_SHORT).show();
                });
    }
}