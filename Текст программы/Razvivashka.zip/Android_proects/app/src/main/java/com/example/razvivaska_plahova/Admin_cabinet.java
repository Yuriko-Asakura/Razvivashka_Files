package com.example.razvivaska_plahova;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Admin_cabinet extends AppCompatActivity {

    private Button Per;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_cabinet);
        Per = findViewById(R.id.Perehod);
        Per.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Admin_cabinet.this, Admin_dobavlenie_dannix.class));
            }
        });
    }
}