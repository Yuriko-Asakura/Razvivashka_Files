package com.example.razvivaska_plahova;

import com.google.firebase.database.PropertyName;

import java.util.ArrayList;
import java.util.List;

public class Subject {
    private String name;
    private List<String> themes;
    public Subject() {}
    public Subject(String name) {
        this.name = name;
        this.themes = new ArrayList<>();
    }
    public String getName() {
        return name;
    }
    public ArrayList<String> getThemes() {
        return (ArrayList<String>) themes;
    }
    public void addTheme(String theme) {
        themes.add(theme);
    }
    @Override
    public String toString() {
        return name; // Return the subject name
    }
    public Subject(String name, ArrayList<String> themes) {
        this.name = name;
        this.themes = themes;
    }


}
