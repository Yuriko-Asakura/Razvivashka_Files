package com.example.razvivaska_plahova;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Change_the_test extends AppCompatActivity {

    private ArrayAdapter<Subject> subjectAdapter;
    private FirebaseFirestore db;
    private ArrayList<Subject> subjects;
    private ArrayList<String> themes;
    private Spinner spinnerSubject;
    private Spinner spinnerTheme;
    private RecyclerView testRecyclerView;
    private TestAdapter testAdapter;
    private List<Test> testList = new ArrayList<>();
    private List<Test> allTests = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_the_test);
        spinnerSubject = findViewById(R.id.subject_spinner);
        spinnerTheme = findViewById(R.id.theme_spinner);
        testRecyclerView = findViewById(R.id.test_recyclerview);

        subjects = new ArrayList<>();
        themes = new ArrayList<>();

        // Инициализируйте db
        db = FirebaseFirestore.getInstance();

        // Настройка RecyclerView
        testRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        testAdapter = new TestAdapter(testList);
        testRecyclerView.setAdapter(testAdapter);

        subjectAdapter = new ArrayAdapter<Subject>(this, android.R.layout.simple_spinner_item, subjects) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view.findViewById(android.R.id.text1);
                textView.setText(((Subject) getItem(position)).getName());
                return view;
            }
        };
        spinnerSubject.setAdapter(subjectAdapter);

        // Загружаем все тесты из Firestore
        loadTests();
        // Загружаем список предметов
        loadSubjects();

        // Настройка Spinner'ов
        spinnerSubject.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Subject selectedSubject = (Subject) spinnerSubject.getSelectedItem();
                themes.clear();
                List<String> themesList = selectedSubject.getThemes();
                if (themesList != null && !themesList.isEmpty()) {
                    themes.addAll(themesList);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(Change_the_test.this, android.R.layout.simple_spinner_item, themes);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerTheme.setAdapter(adapter);
                } else {
                    // Handle the case when there are no themes
                    spinnerTheme.setAdapter(null); // or some other default adapter
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        spinnerTheme.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Фильтруем тесты по выбранному предмету и теме
                filterTestsBySubjectAndTheme();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // Обработчик нажатия на элемент в RecyclerView
        testRecyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(this, testRecyclerView, new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        // Переход на новую активность при нажатии на карточку
                        Intent intent = new Intent(Change_the_test.this, prohogdenie_Test.class);

                        // Передача данных о тесте в новую активность
                        intent.putExtra("testName", testList.get(position).getname());
                        intent.putExtra("subject", testList.get(position).getSubject());
                        intent.putExtra("theme", testList.get(position).getTheme());

                        startActivity(intent);
                    }

                    @Override
                    public void onLongItemClick(View view, int position) {
                        // Ничего не делаем
                    }
                })
        );
    }

    private void loadSubjects() {
        db.collection("subjects")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            subjects.clear();
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Subject subject = document.toObject(Subject.class);
                                subjects.add(subject);
                            }
                            subjectAdapter.notifyDataSetChanged();
                        } else {
                            Log.d(TAG, "Error getting subjects: ", task.getException());
                        }
                    }
                });
    }

    private void loadTests() {
        db.collection("tests")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            allTests.clear();
                            for (DocumentSnapshot document : task.getResult().getDocuments()) {
                                Test test = document.toObject(Test.class);
                                allTests.add(test);
                            }
                            // Изначально отображаем все тесты
                            testList.addAll(allTests);
                            testAdapter.notifyDataSetChanged();
                        } else {
                            Log.w(TAG, "Error getting documents", task.getException());
                            Toast.makeText(Change_the_test.this, "Ошибка загрузки тестов", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void filterTestsBySubjectAndTheme() {
        String selectedSubject = spinnerSubject.getSelectedItem().toString();
        String selectedTheme = spinnerTheme.getSelectedItem().toString();

        testList.clear();
        for (Test test : allTests) {
            if (test.getSubject().equals(selectedSubject) &&
                    test.getTheme().equals(selectedTheme)) {
                testList.add(test);
            }
        }
        testAdapter.notifyDataSetChanged();
    }

}