package com.example.razvivaska_plahova;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Student_test extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_test);
    }
}