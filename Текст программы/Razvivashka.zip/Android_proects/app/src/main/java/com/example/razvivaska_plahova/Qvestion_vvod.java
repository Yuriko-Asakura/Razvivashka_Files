package com.example.razvivaska_plahova;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class Qvestion_vvod extends AppCompatActivity {
    private Spinner spinnerSubject;
    private Spinner spinnerTheme;
    private EditText editTextAnswer4;
    private Button exit;
    private Button buttonCreateQuestion;
    private EditText editTextQuestionText;
    private ArrayAdapter<Subject> adapter;
    private FirebaseFirestore db;
    private ArrayList<Subject> subjects;
    private ArrayList<String> themes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qvestion_vvod);
        spinnerSubject = findViewById(R.id.spinner_subject);
        spinnerTheme = findViewById(R.id.spinner_theme);
        editTextQuestionText = findViewById(R.id.edit_text_question_text);
        editTextAnswer4 = findViewById(R.id.edit_text_answer4);
        exit = findViewById(R.id.button_exit);
        buttonCreateQuestion = findViewById(R.id.button_create_question);
        db = FirebaseFirestore.getInstance();
        subjects = new ArrayList<>();
        themes = new ArrayList<>();
        adapter = new ArrayAdapter<Subject>(Qvestion_vvod.this, android.R.layout.simple_spinner_item, subjects) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view.findViewById(android.R.id.text1);
                textView.setText(((Subject) getItem(position)).getName());
                return view;
            }
        };
        spinnerSubject.setAdapter(adapter);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Qvestion_vvod.this, Menedger_cabinet.class));
            }
        });
        buttonCreateQuestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createQuestion();

            }
        });

        loadSubjects(); // Call loadSubjects() at the end
        spinnerSubject.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Subject selectedSubject = (Subject) spinnerSubject.getSelectedItem();
                themes.clear();
                List<String> themesList = selectedSubject.getThemes();
                if (themesList != null && !themesList.isEmpty()) {
                    themes.addAll(themesList);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(Qvestion_vvod.this, android.R.layout.simple_spinner_item, themes);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerTheme.setAdapter(adapter);
                } else {
                    // Handle the case when there are no themes
                    spinnerTheme.setAdapter(null); // or some other default adapter
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }
    private void loadSubjects() {
        db.collection("subjects")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            subjects.clear(); // Clear the list before adding new data
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Subject subject = document.toObject(Subject.class);
                                subjects.add(subject);
                            }
                            adapter.notifyDataSetChanged(); // Notify the adapter of data changes
                        } else {
                            Log.d(TAG, "Error getting subjects: ", task.getException());
                        }
                    }
                });
    }

    private void createQuestion() {
        Subject selectedSubject = (Subject) spinnerSubject.getSelectedItem();
        String theme = spinnerTheme.getSelectedItem().toString();
        String questionText = editTextQuestionText.getText().toString();
        String correctAnswer = editTextAnswer4.getText().toString();

        String answer1 = "";
        String answer2 = "";
        String answer3 = "";
        String CorrectAncwer = correctAnswer;
        String Qvestion_type = "Вопрос с вводимом ответом";
        Questions question = new Questions(selectedSubject.getName(), theme, questionText, answer1, answer2, answer3, CorrectAncwer,Qvestion_type);
        Toast.makeText(Qvestion_vvod.this, "Question", Toast.LENGTH_SHORT).show();

        db.collection("Questions").add(question).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                Toast.makeText(Qvestion_vvod.this, "Вопрос успешно создан", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Qvestion_vvod.this, "Ошибка при создании вопроса", Toast.LENGTH_SHORT).show();
            }
        });
    }
}