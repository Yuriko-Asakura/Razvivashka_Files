package com.example.razvivaska_plahova;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Admin_dobavlenie_dannix extends AppCompatActivity {

    private Spinner spinnerSubject;
    private Spinner spinnerTheme;
    private EditText editTextQuestionTitle;
    private EditText editTextQuestionText;
    private EditText editTextAnswer1;
    private EditText editTextAnswer2;
    private EditText editTextAnswer3;
    private EditText editTextAnswer4;
    private EditText editTextSubjectName;
    private EditText editTextThemeName;
    private Button buttonCreateQuestion;
    private Button buttonAddSubject,button_updateSubject,button_updateTheme,button_deleteSubject,button_deleteTheme;
    private Button buttonAddTheme;
    private ArrayAdapter<Subject> adapter;
    private FirebaseFirestore db;
    private ArrayList<Subject> subjects;
    private ArrayList<String> themes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dobavlenie_dannix);

        db = FirebaseFirestore.getInstance();

        spinnerSubject = findViewById(R.id.spinner_subject);
        spinnerTheme = findViewById(R.id.spinner_theme);
        editTextSubjectName = findViewById(R.id.editTextSubjectName);
        buttonAddSubject = findViewById(R.id.button_add_subject);
        buttonAddTheme = findViewById(R.id.button_add_theme);
        button_deleteSubject = findViewById(R.id.button_deleteSubject);
        button_deleteTheme  = findViewById(R.id.button_deleteTheme);
        subjects = new ArrayList<>();
        themes = new ArrayList<>();

        adapter = new ArrayAdapter<Subject>(this, android.R.layout.simple_spinner_item, subjects) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view.findViewById(android.R.id.text1);
                textView.setText(((Subject) getItem(position)).getName());
                return view;
            }
        };
        spinnerSubject.setAdapter(adapter);
        buttonAddSubject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addSubject();
            }
        });
        button_deleteSubject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteSubject();
            }
        });
        button_deleteTheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteTheme();
            }
        });
        buttonAddTheme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTheme();
            }
        });

        loadSubjects(); // Call loadSubjects() at the end
        spinnerSubject.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Subject selectedSubject = (Subject) spinnerSubject.getSelectedItem();
                themes.clear();
                List<String> themesList = selectedSubject.getThemes();
                if (themesList != null && !themesList.isEmpty()) {
                    themes.addAll(themesList);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(Admin_dobavlenie_dannix.this, android.R.layout.simple_spinner_item, themes);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerTheme.setAdapter(adapter);
                } else {
                    // Handle the case when there are no themes
                    spinnerTheme.setAdapter(null); // or some other default adapter
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });


    }
    private void loadSubjects() {
        db.collection("subjects")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            subjects.clear(); // Clear the list before adding new data
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Subject subject = document.toObject(Subject.class);
                                subjects.add(subject);
                            }
                            adapter.notifyDataSetChanged(); // Notify the adapter of data changes
                        } else {
                            Log.d(TAG, "Error getting subjects: ", task.getException());
                        }
                    }
                });
    }
    private void addSubject() {
        String subjectName = editTextSubjectName.getText().toString();
        Subject subject = new Subject(subjectName);
        db.collection("subjects").document(subjectName).set(new HashMap<String, String>() {{
            put("name", subjectName);
        }});
        subjects.add(subject);
        adapter.notifyDataSetChanged(); // Now this should work
        spinnerSubject.setAdapter(adapter);
    }
    private void deleteSubject() {
        String subjectName = editTextSubjectName.getText().toString();

        db.collection("subjects").document(subjectName).delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Обновляем список subjects после удаления документа
                        // Пример, предполагая, что subjects - это ArrayList
                        subjects.remove(subjectName);

                        Toast.makeText(Admin_dobavlenie_dannix.this, "Предмет успешно удалён", Toast.LENGTH_SHORT).show();
                        adapter.notifyDataSetChanged();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(Admin_dobavlenie_dannix.this, "Ошибка при удаление предмета: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void addTheme() {
        // Создаем всплывающее окно с полем ввода для имени темы
        AlertDialog.Builder builder = new AlertDialog.Builder(Admin_dobavlenie_dannix.this);
        builder.setTitle("Новая тема");

        // Создаем поле ввода для имени темы
        final EditText input = new EditText(Admin_dobavlenie_dannix.this);
        builder.setView(input);

        // Устанавливаем кнопки "ОК" и "Отмена"
        builder.setPositiveButton("ОК", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                String themeName = input.getText().toString();
                Subject selectedSubject = (Subject) spinnerSubject.getSelectedItem();

                // Проверяем, существует ли тема в списке тем предмета
                if (selectedSubject.getThemes().contains(themeName)) {
                    // Если тема уже есть, выводим сообщение об ошибке
                    Toast.makeText(Admin_dobavlenie_dannix.this, "Тема уже существует!", Toast.LENGTH_SHORT).show();
                } else {
                    // Если темы нет, добавляем ее в список тем предмета
                    selectedSubject.addTheme(themeName);
                    // Обновляем список тем в Firestore
                    db.collection("subjects").document(selectedSubject.getName()).update("themes", FieldValue.arrayUnion(themeName));
                    // Обновляем список тем в адаптере
                    themes.clear();
                    themes.addAll(selectedSubject.getThemes());
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(Admin_dobavlenie_dannix.this, android.R.layout.simple_spinner_item, themes);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerTheme.setAdapter(adapter);
                }
            }
        });
        builder.setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });

        // Создаем и показываем диалоговое окно
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    private void deleteTheme() {
        Subject selectedSubject = (Subject) spinnerSubject.getSelectedItem();
        String themeName = (String) spinnerTheme.getSelectedItem();

        List<String> themes = selectedSubject.getThemes();

        // Проверяем, что тема действительно существует в списке
        if (themes.contains(themeName)) {
            themes.remove(themeName); // Удаляем тему по имени
            // Обновляем данные
            try {
                db.collection("subjects").document(selectedSubject.getName()).update("themes", themes)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(Admin_dobavlenie_dannix.this, "Тема успешно удалена", Toast.LENGTH_SHORT).show();
                                adapter.notifyDataSetChanged();
                            }
                        });
            } catch (Exception e) {
                Toast.makeText(Admin_dobavlenie_dannix.this, "Ошибка удалении темы: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(Admin_dobavlenie_dannix.this, "Тема не найдена", Toast.LENGTH_SHORT).show();
        }
    }

}
