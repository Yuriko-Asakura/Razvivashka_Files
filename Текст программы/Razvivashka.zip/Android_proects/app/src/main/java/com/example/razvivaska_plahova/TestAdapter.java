package com.example.razvivaska_plahova;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TestAdapter extends RecyclerView.Adapter<TestAdapter.TestViewHolder> {

    private List<Test> testList;

    public TestAdapter(List<Test> testList) {
        this.testList = testList;
    }

    @NonNull
    @Override
    public TestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.test_item, parent, false);
        return new TestViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TestViewHolder holder, int position) {
        Test test = testList.get(position);
        holder.nameTextView.setText(test.getname());
        holder.subjectTextView.setText("Предмет: " + test.getSubject());
        holder.themeTextView.setText("Тема: " + test.getTheme());
    }

    @Override
    public int getItemCount() {
        return testList.size();
    }

    public void updateTests(List<Test> tests) {
        this.testList = tests;
        notifyDataSetChanged();
    }

    public static class TestViewHolder extends RecyclerView.ViewHolder {
        public TextView nameTextView, subjectTextView, themeTextView;

        public TestViewHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.test_name);
            subjectTextView = itemView.findViewById(R.id.test_subject);
            themeTextView = itemView.findViewById(R.id.test_theme);
        }
    }
}