package com.example.razvivaska_plahova;

import java.util.List;

public class Questions {
    private String subject;
    private String theme;
    private String questionText;
    private String answer1;
    private String answer2;
    private String answer3;
    private String correctAnswer;
    private String qvestion_type;

    public Questions(String subject, String theme, String questionText, String answer1, String answer2, String answer3, String correctAnswer, String qvestion_type) {
        this.subject = subject;
        this.theme = theme;
        this.questionText = questionText;
        this.answer1 = answer1;
        this.answer2 = answer2;
        this.answer3 = answer3;
        this.correctAnswer = correctAnswer;
        this.qvestion_type = qvestion_type;
    }
    public Questions(String questionText, String answer1, String answer2, String answer3, String correctAnswer, String qvestion_type) {
        this.questionText = questionText;
        this.answer1 = answer1;
        this.answer2 = answer2;
        this.answer3 = answer3;
        this.correctAnswer = correctAnswer;
        this.qvestion_type = qvestion_type;
    }
    // Геттеры для доступа к полям
    public String getSubject() {
        return subject;
    }

    public String getTheme() {
        return theme;
    }


    public String getQuestionText() {
        return questionText;
    }

    public String getAnswer1() {
        return answer1;
    }

    public String getAnswer2() {
        return answer2;
    }

    public String getAnswer3() {
        return answer3;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }
    public Questions() {
        // Default constructor
    }
    public String getqvestion_type()
    {
        return qvestion_type;
    }

}
