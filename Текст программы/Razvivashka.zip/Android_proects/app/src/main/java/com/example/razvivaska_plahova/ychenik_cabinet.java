package com.example.razvivaska_plahova;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ychenik_cabinet extends AppCompatActivity {
    private Button buttonCreateTest, result;
    private TextView email_view,log_view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ychenik_cabinet);
        Intent intent = getIntent();
        buttonCreateTest = findViewById(R.id.test_baton);
        result = findViewById(R.id.test_res_baton);
        email_view = findViewById(R.id.pochta);
        log_view = findViewById(R.id.log);
        log_view.setText(intent.getStringExtra("login"));
        email_view.setText(intent.getStringExtra("email"));
        buttonCreateTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ychenik_cabinet.this, Change_the_test.class));
            }
        });
        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ychenik_cabinet.this, Result_ycheniki.class));
            }
        });
    }
}