package com.example.razvivaska_plahova;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.ArrayList;
import java.util.List;

public class Meneger_create_a_tests extends AppCompatActivity {
    private Spinner spinnerSubjects;
    private Button buttonCreateTest;
    private Spinner spinnerThemes;
    private Spinner spinnerQuestions;

    private EditText name_test;
    private FirebaseFirestore db;
    private ArrayAdapter<Subject> adapter;
    private ArrayList<Subject> subjects;
    private ArrayList<String> themes;
    private ArrayList<String> qvestion;
    private ArrayList<Questions> questionsList; // Список вопросов для Spinner

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meneger_create_atests);
        spinnerSubjects = findViewById(R.id.spinner_subjects);
        spinnerThemes = findViewById(R.id.spinner_themes);
        spinnerQuestions = findViewById(R.id.spinner_questions);
        name_test = findViewById(R.id.edit_text_question_title);
        buttonCreateTest = findViewById(R.id.button_create_test);
        subjects = new ArrayList<>();
        themes = new ArrayList<>();
        questionsList = new ArrayList<>(); // Инициализация списка вопросов

        adapter = new ArrayAdapter<Subject>(this, android.R.layout.simple_spinner_item, subjects) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView textView = (TextView) view.findViewById(android.R.id.text1);
                textView.setText(((Subject) getItem(position)).getName());
                return view;
            }
        };
        spinnerSubjects.setAdapter(adapter);
        db = FirebaseFirestore.getInstance();

        buttonCreateTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createTest();
            }
        });

        // Загрузка предметов
        loadSubjects();

        // Обработчик выбора предмета
        spinnerSubjects.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Subject selectedSubject = (Subject) parent.getItemAtPosition(position);
                loadThemes(selectedSubject);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nothing selected
            }
        });

        // Обработчик выбора темы
        spinnerThemes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedTheme = (String) parent.getItemAtPosition(position);
                loadQuestions(selectedTheme);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nothing selected
            }
        });
    }

    // Метод для загрузки тем, принимающий выбранный предмет
    private void loadThemes(Subject selectedSubject) {
        themes.clear(); // Очищаем список тем
        List<String> themesList = selectedSubject.getThemes();
        if (themesList != null && !themesList.isEmpty()) {
            themes.addAll(themesList);
            ArrayAdapter<String> adapter = new ArrayAdapter<>(Meneger_create_a_tests.this, android.R.layout.simple_spinner_item, themes);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerThemes.setAdapter(adapter);
        } else {
            // Handle the case when there are no themes
            spinnerThemes.setAdapter(null); // or some other default adapter
        }
    }

    // Метод для загрузки вопросов
    private void loadQuestions(String selectedTheme) {
        // Get the selected subject and theme
        String selectedSubject = null;
        if (spinnerSubjects.getSelectedItem() != null) {
            selectedSubject = spinnerSubjects.getSelectedItem().toString();
        }

        if (selectedSubject != null && selectedTheme != null) {
            // Query Firestore for questions based on selected subject and theme
            db.collection("Questions")
                    .whereEqualTo("subject", selectedSubject)
                    .whereEqualTo("theme", selectedTheme)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                questionsList.clear(); // Очищаем список вопросов
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Questions question = document.toObject(Questions.class);
                                    questionsList.add(question); // Добавляем объект Questions
                                }

                                // Create and set the adapter for spinnerQuestions
                                ArrayAdapter<Questions> adapter = new ArrayAdapter<Questions>(getApplicationContext(), android.R.layout.simple_spinner_item, questionsList) {
                                    @Override
                                    public View getView(int position, View convertView, ViewGroup parent) {
                                        View view = super.getView(position, convertView, parent);
                                        TextView textView = (TextView) view.findViewById(android.R.id.text1);
                                        textView.setText(((Questions) getItem(position)).getQuestionText()); // Изменяем текст
                                        return view;
                                    }

                                    // Optional: Customize the appearance of the dropdown view
                                    @Override
                                    public View getDropDownView(int position, View convertView, ViewGroup parent) {
                                        View view = super.getDropDownView(position, convertView, parent);
                                        TextView textView = (TextView) view.findViewById(android.R.id.text1);
                                        textView.setText(((Questions) getItem(position)).getQuestionText()); // Изменяем текст
                                        return view;
                                    }
                                };
                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                spinnerQuestions.setAdapter(adapter);
                            } else {
                                Log.w("Error", "Error loading questions", task.getException());
                                // Handle the error (e.g., display an error message to the user)
                            }
                        }
                    });
        } else {
            Log.w("Error", "Subject or Theme is null");
            // Handle the situation where either subject or theme is null (e.g., display an error message)
        }
    }

    private void loadSubjects() {
        db.collection("subjects")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            subjects.clear(); // Clear the list before adding new data
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Subject subject = document.toObject(Subject.class);
                                subjects.add(subject);
                            }
                            adapter.notifyDataSetChanged(); // Notify the adapter of data changes
                        } else {
                            Log.d(TAG, "Error getting subjects: ", task.getException());
                        }
                    }
                });
    }

    private void createTest() {
        // Get the selected subject, theme, and questions
        String selectedSubject = spinnerSubjects.getSelectedItem().toString();
        String selectedTheme = spinnerThemes.getSelectedItem().toString();
        Questions selectedQuestion = (Questions) spinnerQuestions.getSelectedItem();
        String name_ = name_test.getText().toString();
        String Names = name_;

        // Проверка на выбранные поля
        if (selectedSubject.isEmpty() || selectedTheme.isEmpty() || selectedQuestion == null || Names.isEmpty()) {
            Toast.makeText(Meneger_create_a_tests.this, "Выберите предмет, тему и вопрос!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if a test with the same name already exists, but only if the subject and theme are the same
        db.collection("tests")
                .whereEqualTo("name", Names)
                .whereEqualTo("subject", selectedSubject)
                .whereEqualTo("theme", selectedTheme)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            if (!task.getResult().isEmpty()) {
                                // Test with the same name exists, show a dialog
                                showConfirmationDialog(Names, selectedQuestion, selectedSubject, selectedTheme);
                            } else {
                                // Test with the same name does not exist, create a new test
                                createTestWithNewQuestion(Names, selectedQuestion, selectedSubject, selectedTheme);
                            }
                        } else {
                            Log.w("TestCreation", "Error checking for existing test", task.getException());
                            Toast.makeText(Meneger_create_a_tests.this, "Ошибка, повторите ещё раз", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
    private void showConfirmationDialog(String testName, Questions selectedQuestion, String selectedSubject, String selectedTheme) {
        AlertDialog.Builder builder = new AlertDialog.Builder(Meneger_create_a_tests.this);
        builder.setTitle("Тест уже существует");
        builder.setMessage("Вы хотите добавить этот вопрос к тесту " + testName + "?");
        builder.setPositiveButton("Да", (dialog, which) -> {
            // Add the question to the existing test
            addQuestionToExistingTest(testName, selectedQuestion, selectedSubject, selectedTheme);
        });
        builder.setNegativeButton("Нет", (dialog, which) -> {
            // Do nothing, user canceled
        });
        builder.show();
    }

    // Create a new test with the selected question
    private void createTestWithNewQuestion(String testName, Questions selectedQuestion, String selectedSubject, String selectedTheme) {
        DocumentReference testRef = db.collection("tests").document();
        Test test = new Test(testName, selectedSubject, selectedTheme, new ArrayList<>());
        test.getQuestions().add(selectedQuestion);

        testRef.set(test)
                .addOnSuccessListener(documentReference -> {
                    Log.d("TestCreation", "Test created successfully");
                    Toast.makeText(Meneger_create_a_tests.this, "Тест успешно создан", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Log.w("TestCreation", "Error creating test", e);
                    Toast.makeText(Meneger_create_a_tests.this, "Ошибка при создания теста", Toast.LENGTH_SHORT).show();
                });
    }

    // Add the selected question to an existing test
    private void addQuestionToExistingTest(String testName, Questions selectedQuestion, String selectedSubject, String selectedTheme) {
        db.collection("tests")
                .whereEqualTo("name", testName)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            if (!task.getResult().isEmpty()) {
                                for (DocumentSnapshot document : task.getResult().getDocuments()) {
                                    DocumentReference testRef = document.getReference();
                                    testRef.update("questions", FieldValue.arrayUnion(selectedQuestion))
                                            .addOnSuccessListener(aVoid -> {
                                                Log.d("TestCreation", "Question added to existing test successfully");
                                                Toast.makeText(Meneger_create_a_tests.this, "Вопрос успешно добавлен", Toast.LENGTH_SHORT).show();
                                            })
                                            .addOnFailureListener(e -> {
                                                Log.w("TestCreation", "Error adding question to existing test", e);
                                                Toast.makeText(Meneger_create_a_tests.this, "Ошибка при добавлении вопроса", Toast.LENGTH_SHORT).show();
                                            });
                                }
                            }
                        } else {
                            Log.w("TestCreation", "Error updating test", task.getException());
                            Toast.makeText(Meneger_create_a_tests.this, "Ошибка обновления теста", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
class Test {
    private  String name;
    private String subject;
    private String theme;
    private List<Questions> questions;
    public Test(String name,String subject, String theme, ArrayList<Questions> questions) {
        this.name = name;
        this.subject = subject;
        this.theme = theme;
        this.questions = questions;
    }

    public String getSubject() {
        return subject;
    }
    public Test() {
    }
    public String getname() {
        return name;
    }
    public String getTheme() {
        return theme;
    }

    public List<Questions> getQuestions() {
        return questions;
    }

}