package com.example.razvivaska_plahova;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
// RegisterActivity.java
import android.widget.RadioButton;
import android.widget.RadioGroup;
public class MainActivity extends AppCompatActivity {
    private EditText emailEditText, passwordEditText, loginEditText;
    private RadioButton teacherRadioButton, studentRadioButton;
    private RadioGroup roleRadioGroup;
    private Button registerButton,loginButton,resetPasswordButton;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        emailEditText = findViewById(R.id.email_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);
        loginEditText = findViewById(R.id.login_edit_text);
        teacherRadioButton = findViewById(R.id.teacher_radio_button);
        studentRadioButton = findViewById(R.id.student_radio_button);
        roleRadioGroup = findViewById(R.id.role_radio_group);
        registerButton = findViewById(R.id.register_button);
        resetPasswordButton = findViewById(R.id.resetPasswordButton);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                String login = loginEditText.getText().toString();
                String role;
                RandomIdGenerator generator = new RandomIdGenerator();
                String IDS = generator.generateRandomString(10);

                if (teacherRadioButton.isChecked()) {
                    role = "Учитель";
                } else if (studentRadioButton.isChecked()) {
                    role = "Ученик";
                }else if (studentRadioButton.isChecked()) {
                    role = "Админ";
                }else if (studentRadioButton.isChecked()) {
                    role = "Менеджер";
                }else {
                    Toast.makeText(MainActivity.this, "Пожалуйста выберите роль", Toast.LENGTH_SHORT).show();
                    return;
                }
                String emailPattern = "^[a-zA-Z0-9._%+-]+@gmail\\.com$";
                // Проверка электронной почты и пароля
                if (!email.matches(emailPattern)) {
                    Toast.makeText(MainActivity.this, "Введите адрес электронной почты Gmail", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.length() <= 6) {
                    Toast.makeText(MainActivity.this, "Пароль должен быть длиннее 6 символов", Toast.LENGTH_SHORT).show();
                    return;
                }
                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Get the current user's email
                                    String email = emailEditText.getText().toString();

                                    // Create a new user document in Firestore
                                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                                    DocumentReference userRef = db.collection("users").document(email);

                                    User user = new User(login, role, email, IDS);

                                    // Set the user document with the User object
                                    userRef.set(user)
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    Toast.makeText(MainActivity.this, "Регистрация прошла успешно", Toast.LENGTH_SHORT).show();
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(MainActivity.this, "Упс, ошибка на стороне сервера, проверьте подключены ли вы к интернету", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                } else {
                                    Toast.makeText(MainActivity.this, "Упс, регистрация провалилась. Возможно аккаунт с такой почтой уже есть", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

            }
        });
        loginButton = findViewById(R.id.login_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                final String login = loginEditText.getText().toString();

                // Проверка на пустоту логина
                if (login.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Введите логин", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Проверка на пустоту email и password
                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Введите email и пароль", Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Проверка роли пользователя и логина
                                    db.collection("users").document(email)
                                            .get()
                                            .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                                @Override
                                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                                    if (task.isSuccessful()) {
                                                        DocumentSnapshot document = task.getResult();
                                                        String role = document.getString("role");
                                                        String userLogin = document.getString("login"); // Получение логина из документа
                                                        Intent intent = null;
                                                        if (role != null && userLogin != null) {
                                                            if (role.equals("Ученик") && userLogin.equals(login)) { // Сравнение логина
                                                                // Открыть страницу 1 для учеников
                                                                Toast.makeText(MainActivity.this, "Добро пожаловать, ученик!", Toast.LENGTH_SHORT).show();
                                                                intent = new Intent(MainActivity.this, ychenik_cabinet.class);
                                                                //startActivity(new Intent(MainActivity.this, ychenik_cabinet.class));
                                                            } else if (role.equals("Учитель") && userLogin.equals(login)) { // Сравнение логина
                                                                // Открыть страницу 2 для учителей
                                                                Toast.makeText(MainActivity.this, "Добро пожаловать, учитель!", Toast.LENGTH_SHORT).show();
                                                                intent = new Intent(MainActivity.this, ycitel_cabinet.class);
                                                                // startActivity(new Intent(MainActivity.this, ycitel_cabinet.class));
                                                            } else if (role.equals("Менеджер") && userLogin.equals(login)) { // Сравнение логина
                                                                // Открыть страницу 2 для менеджеров
                                                                Toast.makeText(MainActivity.this, "Добро пожаловать, менеджер!", Toast.LENGTH_SHORT).show();
                                                                intent = new Intent(MainActivity.this, Menedger_cabinet.class);
                                                                /// startActivity(new Intent(MainActivity.this, Menedger_cabinet.class));
                                                            }if (intent != null) {
                                                                // Добавляем данные в Intent перед открытием нового окна
                                                                intent.putExtra("email", email);
                                                                intent.putExtra("login", login);
                                                                startActivity(intent);
                                                            } else {
                                                                Toast.makeText(MainActivity.this, "Неверный логин или пароль", Toast.LENGTH_SHORT).show();
                                                            }
                                                        } else {
                                                            Toast.makeText(MainActivity.this, "Ошибка получения данных пользователя", Toast.LENGTH_SHORT).show();
                                                        }

                                                    } else {
                                                        Toast.makeText(MainActivity.this, "Ошибка получения данных пользователя", Toast.LENGTH_SHORT).show();
                                                    }
                                                }
                                            });
                                } else {
                                    Toast.makeText(MainActivity.this, "Ошибка входа", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });

        resetPasswordButton.setOnClickListener(view -> {
            String emailAddress = emailEditText.getText().toString();

            mAuth.sendPasswordResetEmail(emailAddress)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                //Log.d(TAG, "Email sent.");
                                Toast.makeText(MainActivity.this, "Письмо отправлено", Toast.LENGTH_SHORT).show();

                            }
                        }
                    });
        });
    }

    public class RandomIdGenerator {
        private final Random RANDOM = new Random();


        private String generateRandomString(int length) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < length; i++) {
                int randomChar = RANDOM.nextInt(62);
                if (randomChar < 26) {
                    sb.append((char) (randomChar + 'a'));
                } else if (randomChar < 52) {
                    sb.append((char) (randomChar - 26 + 'A'));
                } else {
                    sb.append((char) (randomChar - 52 + '0'));
                }
            }
            return sb.toString();
        }
    }

    public class User {
        private String login;
        private String role;
        private String email;
        private String IDS;
        public User(String login, String role, String email, String IDS) {
            this.login = login;
            this.role = role;
            this.email = email;
            this.IDS = IDS;
        }

        public String getLogin() {
            return login;
        }

        public void setLogin(String login) {
            this.login = login;
        }

        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }
        public String getemail() {
            return email;
        }

        public void setemail(String role) {
            this.email = email;
        }

        public String getID() {
            return IDS;
        }

        public void setID(String ID) {
            this.IDS = IDS;
        }
    }
}

