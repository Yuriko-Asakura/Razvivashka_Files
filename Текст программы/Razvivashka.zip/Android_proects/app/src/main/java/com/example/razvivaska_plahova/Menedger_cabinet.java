package com.example.razvivaska_plahova;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menedger_cabinet extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menedger_cabinet);

        // Инициализируйте кнопки
        Button quvestion = findViewById(R.id.button_Quvestion);
        Button Test_button = findViewById(R.id.Test_button);
        Button q1 = findViewById(R.id.button_Quvestion_kratki);
        Button q3 = findViewById(R.id.button_Quvestion_3);
        Button Per = findViewById(R.id.Perehod);
        Per.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Menedger_cabinet.this, Admin_dobavlenie_dannix.class));
            }
        });
        quvestion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Menedger_cabinet.this, Quvestion_meneger.class));
            }
        });
        q1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Menedger_cabinet.this, Qvestion_vvod.class));
            }
        });
        q3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Menedger_cabinet.this, Meneger_qvestion_complence.class));
            }
        });
        Test_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Menedger_cabinet.this, Meneger_create_a_tests.class));
            }
        });
    }
}