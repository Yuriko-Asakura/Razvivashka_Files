package com.example.razvivaska_plahova;

import static com.example.razvivaska_plahova.Result.MY_PERMISSIONS_REQUEST_WRITE_STORAGE;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Context;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

// Класс для хранения данных о результате теста
class Result {
    public static final int MY_PERMISSIONS_REQUEST_WRITE_STORAGE = 1;
    private String email;
    private String grade;
    private int result;
    private String subject;
    private String testName;
    private String theme;

    public Result(String email, String grade, int result, String subject, String testName, String theme) {
        this.email = email;
        this.grade = grade;
        this.result = result;
        this.subject = subject;
        this.testName = testName;
        this.theme = theme;
    }

    // Геттеры
    public String getEmail() { return email; }
    public String getGrade() { return grade; }
    public int getResult() { return result; }
    public String getSubject() { return subject; }
    public String getTestName() { return testName; }
    public String getTheme() { return theme; }
}

public class Result_ycheniki extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Button save;
    private ResultsAdapter adapter;
    private List<Result> results = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_ycheniki);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ResultsAdapter(this, results);
        save = findViewById(R.id.save);
        recyclerView.setAdapter(adapter);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            String userEmail = user.getEmail();
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("results")
                    .whereEqualTo("email", userEmail)
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        results.clear();
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            String grade = document.getString("grade");
                            int result = document.getLong("result").intValue();
                            String subject = document.getString("subject");
                            String testName = document.getString("testName");
                            String theme = document.getString("theme");

                            Result resultItem = new Result(userEmail, grade, result, subject, testName, theme);
                            results.add(resultItem);
                        }
                        adapter.notifyDataSetChanged();
                    })
                    .addOnFailureListener(e -> {
                        // Обработка ошибки загрузки данных
                    });
        }

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, "results.txt"); // имя файла
                values.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain"); // тип содержимого
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + File.separator + "Razvivashka"); // путь

                Uri uri = getContentResolver().insert(MediaStore.Files.getContentUri("external"), values); // создание URI для файла

                try {
                    if (uri != null) {
                        OutputStream outputStream = getContentResolver().openOutputStream(uri);
                        for (Result result : results) {
                            if (outputStream != null) {
                                outputStream.write((result.getEmail() + ", Оценка:" +
                                        result.getGrade() + ", Результат в %:" +
                                        String.valueOf(result.getResult()) + ", Предмет:" +
                                        result.getSubject() + ", Название теста:" +
                                        result.getTestName() + ", Тема:" +
                                        result.getTheme() + "\n").getBytes());
                            }
                        }
                        if (outputStream != null) {
                            outputStream.close();
                        }
                        Toast.makeText(Result_ycheniki.this, "Результаты сохранены в папке 'Загрузки'", Toast.LENGTH_SHORT).show();
                    }
                } catch (IOException e) {
                    Log.w("File writing error", "Ошибка при записи файла: " + e.getMessage());
                    Toast.makeText(Result_ycheniki.this, "Ошибка при сохранении файлов: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}

class ResultsAdapter extends RecyclerView.Adapter<ResultsAdapter.ViewHolder> {
    private List<Result> results;
    private Context context;

    public ResultsAdapter(Context context, List<Result> results) {
        this.context = context;
        this.results = results;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.result_item, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Result result = results.get(position);
        holder.testName.setText(result.getTestName());
        holder.subject.setText(result.getSubject());
        holder.grade.setText(result.getGrade());
        holder.result.setText("Результат: " + result.getResult());
    }

    @Override
    public int getItemCount() {
        return results.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView testName;
        public TextView subject;
        public TextView grade;
        public TextView result;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            testName = itemView.findViewById(R.id.testName);
            subject = itemView.findViewById(R.id.subject);
            grade = itemView.findViewById(R.id.grade);
            result = itemView.findViewById(R.id.result);
        }
    }
}
