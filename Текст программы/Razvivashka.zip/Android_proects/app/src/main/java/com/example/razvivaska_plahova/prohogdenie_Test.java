package com.example.razvivaska_plahova;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.DialogInterface;
import android.os.Bundle;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class prohogdenie_Test extends AppCompatActivity {
    private TextView testNameTextView, subjectTextView, themeTextView;
    private TextView questionTextView;
    private RadioGroup answerRadioGroup;
    ConstraintLayout sootvetstvieConstraintLayout;
    ConstraintLayout vvod;
    private Button nextButton;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private List<Questions> questions = new ArrayList<>(); // Список вопросов
    private int currentQuestionIndex = 0; // Индекс текущего вопроса
    private int score = 0;
    private boolean isAnswerChecked = false; // Флаг, чтобы проверять, был ли выбран ответ
    private TextView questionText;
    private LinearLayout answerContainer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prohogdenie_test);
            mAuth = FirebaseAuth.getInstance();
            testNameTextView = findViewById(R.id.testNameTextView);
            subjectTextView = findViewById(R.id.subjectTextView);
            themeTextView = findViewById(R.id.themeTextView);
            questionTextView = findViewById(R.id.questionTextView);
            answerRadioGroup = findViewById(R.id.answerRadioGroup);
            nextButton = findViewById(R.id.nextButton);
            sootvetstvieConstraintLayout = findViewById(R.id.Sootvetstvie);
            vvod = findViewById(R.id.vvods);
            // Получение данных о тесте из Intent
            Intent intent = getIntent();
            String testName = intent.getStringExtra("testName");
            String subject = intent.getStringExtra("subject");
            String theme = intent.getStringExtra("theme");

            testNameTextView.setText("Название теста: " + testName);
            subjectTextView.setText("Предмет: " + subject);
            themeTextView.setText("Тема: " + theme);

            // Загрузка теста из Firestore
            loadTest(testName, subject, theme);

            // Настройка слушателя для кнопки "Следующий"
            nextButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

//                    if (isAnswerChecked) {
//                        checkAnswer();
//                        isAnswerChecked = false;
//                    } else {
//                        Toast.makeText(prohogdenie_Test.this, "Выберите ответ", Toast.LENGTH_SHORT).show();
//                    }
                    checkAnswer();
                }
            });

            // Настройка слушателя для RadioGroup
            answerRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    // Если выбран какой-то RadioButton
                    if (checkedId != -1) {
                        isAnswerChecked = true;
                    } else {
                        isAnswerChecked = false;
                    }
                }
            });
        }

        private void loadTest(String testName, String subject, String theme) {
            db.collection("tests")
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DocumentSnapshot document : task.getResult().getDocuments()) {
                                    if (document.getString("name").equals(testName) &&
                                            document.getString("subject").equals(subject) &&
                                            document.getString("theme").equals(theme)) {
                                        // Найден нужный тест
                                        List<Map<String, Object>> questionsFromFirestore = (List<Map<String, Object>>) document.get("questions");

                                        if (questionsFromFirestore != null && !questionsFromFirestore.isEmpty()) {
                                            // Преобразование вопросов из Firestore в объекты Questions
                                            for (Map<String, Object> questionData : questionsFromFirestore) {
                                                String questionText = (String) questionData.get("questionText");
                                                String answer1 = (String) questionData.get("answer1");
                                                String answer2 = (String) questionData.get("answer2");
                                                String answer3 = (String) questionData.get("answer3");
                                                String correctAnswer = (String) questionData.get("correctAnswer"); //  или  (String) questionData.get("правильный_ответ");
                                                String type = (String) questionData.get("qvestion_type"); //  или  (String) questionData.get("правильный_ответ");

                                                questions.add(new Questions(questionText, answer1, answer2, answer3, correctAnswer, type));
                                            }

                                            Collections.shuffle(questions, new Random());
                                            // Отобразите первый вопрос
                                            showNextQuestion();
                                            return; // Выходим из цикла, так как тест найден
                                        } else {
                                            // Тест не содержит вопросов
                                            Toast.makeText(prohogdenie_Test.this, "Тест не содержит вопросов", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                }

                                // Тест не найден
                                Toast.makeText(prohogdenie_Test.this, "Тест не найден", Toast.LENGTH_SHORT).show();
                            } else {
                                // Ошибка при чтении данных
                                Toast.makeText(prohogdenie_Test.this, "Ошибка загрузки теста", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }

        private void showNextQuestion() {
            if (currentQuestionIndex < questions.size()) {
                // Получаем текущий вопрос
                Questions currentQuestion = questions.get(currentQuestionIndex);
                questionTextView.setText(currentQuestion.getQuestionText());
                if (currentQuestion.getqvestion_type().equals("1 правильный, 3 неправильных")) {
                    sootvetstvieConstraintLayout.setVisibility(View.GONE);
                    vvod.setVisibility(View.GONE);
                    answerRadioGroup.setVisibility(View.VISIBLE); // Отображаем RadioGroup// Отобразите варианты ответов
                    RadioButton answerOption1 = findViewById(R.id.answerOption1);
                    answerOption1.setText(currentQuestion.getAnswer1());
                    RadioButton answerOption2 = findViewById(R.id.answerOption2);
                    answerOption2.setText(currentQuestion.getAnswer2());
                    RadioButton answerOption3 = findViewById(R.id.answerOption3);
                    answerOption3.setText(currentQuestion.getAnswer3());
                    RadioButton answerOption4 = findViewById(R.id.answerOption4);
                    answerOption4.setText(currentQuestion.getCorrectAnswer());
                } else if (currentQuestion.getqvestion_type().equals("Вопрос с соответствием")) {
                    answerRadioGroup.setVisibility(View.GONE); // Скрываем RadioGroup
                    sootvetstvieConstraintLayout.setVisibility(View.VISIBLE);
                    vvod.setVisibility(View.GONE);
                    String[] answers = currentQuestion.getAnswer1().split(" ");
                    String[] answers2 = currentQuestion.getAnswer2().split(" ");
                    String[] answers3 = currentQuestion.getAnswer3().split(" ");
                    String[] answers4 = currentQuestion.getCorrectAnswer().split(" ");
                    // Устанавливаем текст в RadioButtons
                    TextView answerOption1 = findViewById(R.id.textView16);
                    answerOption1.setText(answers[0]);
                    TextView answerOption1_1 = findViewById(R.id.text16);
                    answerOption1_1.setText(answers[1]);
                    TextView answerOption2 = findViewById(R.id.text7);
                    answerOption2.setText(answers2[0]);
                    TextView answerOption2_2 = findViewById(R.id.text3);
                    answerOption2_2.setText(answers2[1]);
                    TextView answerOption3 = findViewById(R.id.text5);
                    answerOption3.setText(answers3[0]);
                    TextView answerOption3_3 = findViewById(R.id.text1);
                    answerOption3_3.setText(answers3[1]);
                    TextView answerOption4 = findViewById(R.id.text6);
                    answerOption4.setText(answers4[0]);
                    TextView answerOption4_4 = findViewById(R.id.text4);
                    answerOption4_4.setText(answers4[1]);
                    EditText editTextOtvet = findViewById(R.id.text_otvet);
                    editTextOtvet.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                            // Не используется
                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {
                            // Не используется
                        }

                        @Override
                        public void afterTextChanged(Editable s) {
                            // Проверяем ответ, когда пользователь вводит текст
                            checkAnswer();
                        }
                    });
                   //answerOption4.setVisibility(View.VISIBLE); // Отображаем 4-й вариант ответа (текстовое поле)
                    // ... реализуйте показ текстового поля для свободного ответа
                }else {
                    answerRadioGroup.setVisibility(View.GONE);
                    sootvetstvieConstraintLayout.setVisibility(View.GONE);
                    vvod.setVisibility(View.VISIBLE);
                }
                // Сбросьте выделенный RadioButton
                answerRadioGroup.clearCheck();

                currentQuestionIndex++;
            } else {
                // Тест завершен
                showResults();
            }
        }

        private void checkAnswer() {
            EditText textOtvet1 = findViewById(R.id.text_otvet);
            EditText textOtvet2 = findViewById(R.id.text_otvet1);
            EditText textOtvet3 = findViewById(R.id.text_otvet3);
            EditText textOtvet4 = findViewById(R.id.text_otvet4);
            Questions currentQuestion = questions.get(currentQuestionIndex - 1); // Исправлено: берем предыдущий вопрос
            String userAnswer = findViewById(R.id.text_otvet).getContext().toString();
            // Проверяем тип вопроса
            if (currentQuestion.getqvestion_type().equals("Вопрос с соответствием")) {
                String userAnswer1 = textOtvet1.getText().toString().trim();
                String userAnswer2 = textOtvet2.getText().toString().trim();
                String userAnswer3 = textOtvet3.getText().toString().trim();
                String userAnswer4 = textOtvet4.getText().toString().trim();

                // Проверяем правильность введенных данных
                if (!userAnswer1.isEmpty() && !userAnswer2.isEmpty() && !userAnswer3.isEmpty() && !userAnswer4.isEmpty()) {
                    // Проверяем, совпадают ли ответы пользователя с правильными ответами
                    boolean isCorrect =
                            userAnswer1.equalsIgnoreCase(currentQuestion.getAnswer1().trim()) &&
                                    userAnswer2.equalsIgnoreCase(currentQuestion.getAnswer2().trim()) &&
                                    userAnswer3.equalsIgnoreCase(currentQuestion.getAnswer3().trim()) &&
                                    userAnswer4.equalsIgnoreCase(currentQuestion.getCorrectAnswer().trim());

                    // Выводим результат проверки
                    if (isCorrect) {
                        score++;
                        Toast.makeText(this, "Правильно!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Неверно", Toast.LENGTH_SHORT).show();
                    }
                    showNextQuestion();
                } else {
                    Toast.makeText(this, "Заполните все поля ответа.", Toast.LENGTH_SHORT).show();
                }
            } else if (currentQuestion.getqvestion_type().equals("1 правильный, 3 неправильных")) {
                int selectedId = answerRadioGroup.getCheckedRadioButtonId();
                if (selectedId != -1) {
                    RadioButton selectedRadioButton = findViewById(selectedId);
                    String selectedAnswer = selectedRadioButton.getText().toString();

                    if (selectedAnswer.equalsIgnoreCase(currentQuestion.getCorrectAnswer())) {
                        score++;
                        Toast.makeText(this, "Правильно!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Неверно", Toast.LENGTH_SHORT).show();
                    }
                    showNextQuestion();
                } else {
                    Toast.makeText(this, "Выберите ответ", Toast.LENGTH_SHORT).show();
                }
            } else if (currentQuestion.getqvestion_type().equals("Вопрос с вводимом ответом")) {
                EditText Otvet1_vvesti = findViewById(R.id.Otvet_vvesti);
                if (Otvet1_vvesti.getText().toString().trim().isEmpty()) {
                    Toast.makeText(this, "Поле ответа не может быть пустым!", Toast.LENGTH_SHORT).show();
                    return; // Выход из функции, если поле пустое
                }
                String userAnswers = Otvet1_vvesti.getText().toString().trim();
                if (userAnswers.equalsIgnoreCase(currentQuestion.getCorrectAnswer().trim())) {
                    // Ответ верный
                    score++;
                    Toast.makeText(this, "Правильно!", Toast.LENGTH_SHORT).show();showNextQuestion();
                }
                else {
                    // Ответ неверный
                    Toast.makeText(this, "Неверно", Toast.LENGTH_SHORT).show();showNextQuestion();
                }
            }
        }


    private void showResults() {
        // Вычисление процента правильных ответов
        int percentage = (score * 100) / questions.size();

        // Отображение результатов
        Toast.makeText(this, "Тест завершен! Ваш результат: " + percentage + "%", Toast.LENGTH_LONG).show();

        // Создание диалогового окна с вопросом о сохранении результата
        new AlertDialog.Builder(this)
                .setTitle("Сохранить результат?")
                .setMessage("Хотите сохранить результат теста?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Сохраняем результат в Firestore
                        saveResult(percentage);
                    }
                })
                .setNegativeButton(android.R.string.no, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void saveResult(int percentage) {
        String email = mAuth.getCurrentUser().getEmail(); // Получаем почту пользователя
        Intent intent = getIntent();
        String subject = intent.getStringExtra("subject");
        String theme = intent.getStringExtra("theme");
        String testName = intent.getStringExtra("testName");
        // Создаем Map с данными для сохранения
        String grade = calculateGrade(percentage);

        // Создаем Map с данными для сохранения
        Map<String, Object> resultData = new HashMap<>();
        resultData.put("email", email);
        resultData.put("subject", subject);
        resultData.put("theme", theme);
        resultData.put("testName", testName);
        resultData.put("result", percentage);
        resultData.put("grade", grade);

        // Сохраняем данные в коллекцию "results" в Firestore
        db.collection("results")
                .add(resultData)
                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentReference> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(prohogdenie_Test.this, "Результат сохранен!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(prohogdenie_Test.this, ychenik_cabinet.class));
                        } else {
                            Toast.makeText(prohogdenie_Test.this, "Ошибка сохранения результата!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(prohogdenie_Test.this, ychenik_cabinet.class));
                        }
                    }
                });
    }
    private String calculateGrade(int percentage) {
        if (percentage < 70) {
            return "2";
        } else if (percentage >= 70 && percentage <= 80) {
            return "3";
        } else if (percentage >= 81 && percentage <= 90) {
            return "4";
        } else if (percentage >= 91 && percentage <= 100) {
            return "5";
        } else {
            return "Неизвестно"; // Добавьте обработку для некорректных значений
        }
    }
}