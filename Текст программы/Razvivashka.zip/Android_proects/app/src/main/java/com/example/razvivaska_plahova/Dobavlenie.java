package com.example.razvivaska_plahova;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Dobavlenie extends AppCompatActivity {
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    EditText subjectEditText;
    Button saveButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dobavlenie);
        Button addButton = findViewById(R.id.button);
        EditText userInputEditText = findViewById(R.id.textView);
        DocumentReference documentRef = FirebaseFirestore.getInstance().collection("Subjects").document("Subjects");

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userInputData = userInputEditText.getText().toString();

                // Get the current list of data from the document
                documentRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                // Get the current list of data from the document
                                List<String> dataList = (List<String>) document.get("dataList");

                                // Add the new data to the list
                                dataList.add(userInputData);

                                // Update the document with the new list
                                Map<String, Object> updateData = new HashMap<>();
                                updateData.put("dataList", dataList);
                                documentRef.update(updateData);
                            } else {
                                // If the document doesn't exist, create a new one with the initial list
                                List<String> dataList = new ArrayList<>();
                                dataList.add(userInputData);
                                Map<String, Object> data = new HashMap<>();
                                data.put("dataList", dataList);
                                documentRef.set(data);
                            }
                        } else {
                            Log.w("Firestore", "Error getting document", task.getException());
                        }

                    }
                });
            }
        });
    }
}